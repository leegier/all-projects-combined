# AI Prompt Vault — $19 Digital Product

**A professional, browser-based prompt management tool. Single HTML file. Zero dependencies. Works offline.**

---

## 🔐 What Is AI Prompt Vault?

AI Prompt Vault is a sleek, dark-themed prompt library and manager that lives entirely in one HTML file. Open it in any browser, save it to your desktop, and you have a fully functional AI prompt organizer — no accounts, no internet, no subscriptions.

Built for AI power users, freelancers, marketers, developers, and content creators who are tired of losing their best prompts in Notion, Notes, or random text files.

---

## ✨ Features

### Core Functionality
- **50 pre-loaded, battle-tested prompts** across 7 categories — not filler, actual pro-grade prompts
- **Add, edit, and delete** your own custom prompts
- **One-click copy** to clipboard with a copy counter
- **Star ratings (1–5)** on every prompt
- **Favorite toggle** to bookmark your go-to prompts
- **LocalStorage persistence** — your data survives browser refreshes automatically

### Organization
- **7 Categories**: Writing, Coding, Marketing, SEO, Sales, Image Gen, Business
- **Tags system** — add unlimited tags to any prompt
- **Filter by category, favorites, top-rated, or most-used** via sidebar
- **Smart search** — searches title, prompt text, tags, and category simultaneously
- **Tag-click filtering** — click any tag chip to instantly filter by that tag

### Sorting & Views
- **6 sort options**: Newest, Oldest, A→Z, Z→A, Top Rated, Most Copied
- **Grid view** (card-based) and **List view** (compact)

### Import / Export
- **Export all prompts as JSON** — for backup or sharing
- **Export favorites only**
- **Import from JSON file** (drag & drop or file picker)
- **Paste JSON directly** into the import text area
- **Duplicate detection** — won't import the same prompt twice

### UX Details
- **Keyboard shortcuts**: `Ctrl+K` to search, `Ctrl+N` to add prompt, `Esc` to close modals
- **Stats dashboard** — shows total prompts, favorites, total copies, and top category
- **Animated toast notifications** for every action
- **Fully responsive** — works on mobile browsers too

---

## 📦 What's Included

| File | Description |
|------|-------------|
| `AI-Prompt-Vault-v1.html` | The complete product — open in any browser |
| `README.md` | This file |

---

## 🚀 How to Use

1. Open `AI-Prompt-Vault-v1.html` in any modern browser (Chrome, Firefox, Safari, Edge)
2. Browse the 50 included prompts or add your own
3. Click **Copy** to send any prompt to your clipboard
4. Rate, favorite, and tag your prompts to stay organized
5. Export your library as JSON anytime for backup

**No installation. No account. No internet required.**

---

## 📋 The 50 Included Prompts

### ✍️ Writing (8 prompts)
- Long-form blog post generator
- 5-part cold email sequence
- YouTube script with hook & CTA
- LinkedIn thought leadership article
- Conversion-optimized product description
- Professional case study writer
- Newsletter issue writer
- Sales page headline pack (20 variations)

### 💻 Coding (8 prompts)
- Code review & refactor expert
- SQL query builder & optimizer
- REST API design (OpenAPI spec)
- Debug this code (step-by-step)
- React component generator
- System design interview answer
- Python script generator
- Git commit message writer

### 📣 Marketing (7 prompts)
- Multi-platform ad copy creator (Facebook, Google, YouTube)
- Brand voice & messaging framework
- 30-day content calendar builder
- Influencer outreach email
- Full product launch email sequence
- Go-to-market strategy brief
- Viral social media post generator

### 🔎 SEO (6 prompts)
- Keyword research & cluster builder
- On-page SEO audit checklist
- SEO-optimized blog post brief
- Link building outreach email sequence
- JSON-LD schema markup generator
- Competitor SEO analysis framework

### 💰 Sales (6 prompts)
- B2B discovery call script (SPIN methodology)
- Professional services proposal template
- 10-objection handling playbook
- Follow-up sequence for ghosted prospects
- LinkedIn DM outreach sequence
- Pricing page copy generator

### 🎨 Image Gen (7 prompts)
- Photorealistic portrait (Midjourney/SD)
- Epic fantasy landscape
- Clean product photography
- Minimal logo design concept
- Cinematic movie still
- Character concept design sheet
- Architectural interior visualization

### 📊 Business (8 prompts)
- Business plan executive summary
- Job description writer
- SWOT analysis generator
- Investor pitch deck outline (12 slides)
- SOP (Standard Operating Procedure) writer
- Meeting agenda creator
- Customer persona builder
- OKR framework builder

---

## 💡 Selling Points

- **"Never lose a great prompt again"** — the core pain point
- **Works offline** — unlike cloud tools, it works on a plane
- **Your data stays yours** — nothing stored on external servers
- **One-time purchase** — no subscription, no recurring fee
- **Instantly useful** — 50 real prompts loaded on first open
- **Fully customizable** — add unlimited prompts, build your own library

---

## 🎯 Target Audience

- Freelancers using ChatGPT/Claude daily
- Solopreneurs and agency owners
- Content creators and copywriters
- Developers using AI coding assistants
- Marketing teams managing prompt libraries
- Anyone who's lost a great prompt in a messy doc

---

## 🏷️ Suggested Listing Copy

**Headline:** Stop losing your best AI prompts. Organize, rate, and copy them in one click.

**Short description:** AI Prompt Vault is a single-file, offline-ready prompt manager with 50 expert-crafted prompts built in. Rate them, favorite them, search them, and copy with one click. No subscriptions. No accounts. Just open and go.

**Price:** $19

**Tags:** ai prompts, chatgpt, prompt engineering, productivity, digital tool, offline, no-code

---

## 🔧 Technical Specs

- **Format**: Single HTML file (~90KB)
- **Dependencies**: Zero (pure HTML/CSS/JavaScript)
- **Storage**: Browser LocalStorage (no server, no cloud)
- **Compatibility**: All modern browsers (Chrome 80+, Firefox 75+, Safari 14+, Edge 80+)
- **Mobile**: Responsive design, works on iOS/Android browsers
- **Offline**: Fully functional without internet connection

---

*Built with zero dependencies. Powered by vanilla JavaScript. Ready to ship.*
