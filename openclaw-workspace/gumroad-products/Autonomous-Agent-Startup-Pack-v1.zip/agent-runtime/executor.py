"""
executor.py — Runs a single task using the appropriate tool/LLM call.
Each task type maps to a specific execution strategy.
Writes result back to DB on completion.
"""

import time
import traceback
import aiohttp
import asyncio
from db import update_task, store_memory, log_execution, load_memory

ROUTER_URL = "http://127.0.0.1:11435"
OLLAMA_URL = "http://127.0.0.1:11434"
DEFAULT_MODEL = "llama31-agent:latest"

# System prompts per task type
SYSTEM_PROMPTS = {
    "research": (
        "You are a research agent. Search your knowledge thoroughly. "
        "Return factual, concise findings with key points. No fluff."
    ),
    "write": (
        "You are a professional writer. Produce clean, direct copy. "
        "Return the written content only — no meta-commentary."
    ),
    "code": (
        "You are a senior software engineer. Write working code. "
        "Return only the code block, no explanations unless asked."
    ),
    "browse": (
        "You are a web research agent. Summarize what you would find "
        "at the given URL/query. Be specific and factual."
    ),
    "api": (
        "You are an API integration specialist. Describe the exact API calls "
        "needed, parameters, and expected responses."
    ),
    "analyze": (
        "You are a data analyst. Examine the provided information carefully. "
        "Return structured analysis with clear conclusions."
    ),
    "message": (
        "You are a communication specialist. Draft the exact message requested. "
        "Be direct, professional, and appropriately concise."
    ),
}


async def _call_router(messages: list, model_hint: str = None) -> tuple[str, str]:
    """
    Call model router, return (content, model_used).
    Falls back to direct Ollama if router is down.
    """
    payload = {
        "messages": messages,
        "max_tokens": 2048,
        "temperature": 0.4,
    }

    # Try router first
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{ROUTER_URL}/v1/chat/completions",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=60),
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    content = data["choices"][0]["message"]["content"]
                    if content and content.strip():
                        return content, data.get("model", "router:auto")
    except Exception:
        pass

    # Direct Ollama fallback
    ollama_payload = {
        "model": model_hint or DEFAULT_MODEL,
        "messages": messages,
        "stream": False,
        "options": {"temperature": 0.4, "num_predict": 2048},
    }
    async with aiohttp.ClientSession() as session:
        async with session.post(
            f"{OLLAMA_URL}/api/chat",
            json=ollama_payload,
            timeout=aiohttp.ClientTimeout(total=120),
        ) as resp:
            resp.raise_for_status()
            data = await resp.json()
            return data["message"]["content"], model_hint or DEFAULT_MODEL


async def execute_task(task: dict, goal_description: str, memory: dict) -> str:
    """
    Execute a single task. Returns result string.
    Raises on unrecoverable failure after max retries.
    """
    task_id = task["id"]
    task_type = task.get("type", "analyze")
    description = task["description"]
    goal_id = task["goal_id"]

    system = SYSTEM_PROMPTS.get(task_type, SYSTEM_PROMPTS["analyze"])

    # Build context from memory
    memory_context = ""
    if memory:
        snippets = list(memory.items())[:10]
        memory_context = "\n\nPrior context:\n" + "\n".join(
            f"- {k}: {v}" for k, v in snippets
        )

    user_msg = (
        f"Goal: {goal_description}\n\n"
        f"Task ({task_type}): {description}"
        f"{memory_context}"
    )

    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": user_msg},
    ]

    max_attempts = 2
    last_error = None

    for attempt in range(max_attempts):
        t0 = time.time()
        try:
            content, model_used = await _call_router(messages)
            latency_ms = int((time.time() - t0) * 1000)

            # Log to executions table
            await log_execution(
                task_id=task_id,
                model=model_used,
                input_=user_msg,
                output=content,
                success=True,
                latency_ms=latency_ms,
            )

            # Store result as memory
            await store_memory(goal_id, f"result:{task_id}", content[:500], type_="result")

            # Mark task done
            await update_task(
                task_id=task_id,
                status="done",
                result=content,
                model=model_used,
            )

            return content

        except Exception as e:
            last_error = e
            latency_ms = int((time.time() - t0) * 1000)
            await log_execution(
                task_id=task_id,
                model="unknown",
                input_=user_msg,
                output="",
                success=False,
                latency_ms=latency_ms,
            )
            if attempt < max_attempts - 1:
                await asyncio.sleep(2)

    # All attempts failed
    error_msg = str(last_error)
    await update_task(
        task_id=task_id,
        status="failed",
        error=error_msg,
    )
    raise RuntimeError(f"Task {task_id} failed after {max_attempts} attempts: {error_msg}")


async def execute_tasks_parallel(
    tasks: list[dict],
    goal_description: str,
    goal_id: int,
    max_parallel: int = 3,
) -> dict[str, str]:
    """
    Execute multiple independent tasks in parallel (up to max_parallel at once).
    Returns dict of {task_id: result}.
    """
    memory = await load_memory(goal_id)
    results = {}

    # Mark all as running
    for task in tasks:
        await update_task(task["id"], status="running")

    semaphore = asyncio.Semaphore(max_parallel)

    async def run_one(task):
        async with semaphore:
            try:
                result = await execute_task(task, goal_description, memory)
                results[task["id"]] = result
            except RuntimeError as e:
                results[task["id"]] = f"ERROR: {e}"

    await asyncio.gather(*[run_one(t) for t in tasks])
    return results
