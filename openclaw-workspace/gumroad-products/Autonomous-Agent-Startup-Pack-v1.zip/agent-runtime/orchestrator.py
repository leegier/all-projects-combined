"""
orchestrator.py — Main runtime loop.
Polls for active goals → plans tasks → executes via DAG → marks complete.
Runs forever. Restart-safe (picks up where it left off via DB state).
"""

import asyncio
import time
import traceback
from db import (
    init_db, get_active_goals, create_goal, update_goal_status,
    get_tasks_for_goal, upsert_task, get_stats,
)
from planner import plan_goal
from dag import get_ready_tasks, is_goal_complete, is_goal_failed
from executor import execute_tasks_parallel

POLL_INTERVAL = 5        # seconds between goal queue checks
MAX_PARALLEL_TASKS = 3   # max tasks running at once per goal
MAX_GOALS_RUNNING = 2    # process this many goals concurrently


async def process_goal(goal: dict):
    """Full lifecycle for a single goal: plan → execute → complete."""
    goal_id = goal["id"]
    description = goal["description"]
    print(f"\n[Orchestrator] ▶ Goal {goal_id}: {description[:80]}")

    await update_goal_status(goal_id, "running")

    try:
        # Load existing tasks (restart-safe: skip re-planning if tasks exist)
        tasks = await get_tasks_for_goal(goal_id)
        if not tasks:
            print(f"[Orchestrator]   Planning tasks for goal {goal_id}...")
            planned = await plan_goal(goal_id, description)
            for t in planned:
                await upsert_task(t)
            tasks = await get_tasks_for_goal(goal_id)
            print(f"[Orchestrator]   {len(tasks)} tasks created")

        # DAG execution loop
        max_rounds = 20
        for round_num in range(max_rounds):
            tasks = await get_tasks_for_goal(goal_id)

            if is_goal_complete(tasks):
                print(f"[Orchestrator] ✓ Goal {goal_id} complete ({round_num} rounds)")
                result_summary = _summarize_results(tasks)
                await update_goal_status(goal_id, "completed", result=result_summary)
                return

            if is_goal_failed(tasks):
                failed = [t["id"] for t in tasks if t["status"] == "failed"]
                print(f"[Orchestrator] ✗ Goal {goal_id} failed — stuck tasks: {failed}")
                await update_goal_status(goal_id, "failed")
                return

            ready = get_ready_tasks(tasks)
            if not ready:
                # Nothing ready — wait for running tasks to finish
                running = [t for t in tasks if t["status"] == "running"]
                if running:
                    await asyncio.sleep(2)
                    continue
                else:
                    # Deadlock — no ready, no running, not done, not failed
                    print(f"[Orchestrator] ⚠ Goal {goal_id} deadlocked")
                    await update_goal_status(goal_id, "failed")
                    return

            print(f"[Orchestrator]   Round {round_num+1}: running {len(ready)} tasks: "
                  f"{[t['id'] for t in ready]}")

            await execute_tasks_parallel(
                tasks=ready,
                goal_description=description,
                goal_id=goal_id,
                max_parallel=MAX_PARALLEL_TASKS,
            )

        # Exceeded max rounds
        print(f"[Orchestrator] ⚠ Goal {goal_id} exceeded max rounds — marking failed")
        await update_goal_status(goal_id, "failed")

    except Exception as e:
        print(f"[Orchestrator] ✗ Goal {goal_id} crashed: {e}")
        traceback.print_exc()
        await update_goal_status(goal_id, "failed")


def _summarize_results(tasks: list[dict]) -> str:
    """Concatenate task results into a short summary."""
    parts = []
    for t in tasks:
        if t.get("result"):
            parts.append(f"[{t['id']}] {t['result'][:300]}")
    return "\n---\n".join(parts)[:2000]


async def run():
    """Main orchestrator loop."""
    print("[Orchestrator] Initializing database...")
    await init_db()
    print("[Orchestrator] Runtime started. Polling for goals every "
          f"{POLL_INTERVAL}s...")

    active_goals: dict[int, asyncio.Task] = {}

    while True:
        try:
            goals = await get_active_goals()
            for goal in goals:
                gid = goal["id"]
                # Skip already-running goals
                if gid in active_goals and not active_goals[gid].done():
                    continue
                # Cap concurrent goals
                running_count = sum(1 for t in active_goals.values() if not t.done())
                if running_count >= MAX_GOALS_RUNNING:
                    break
                # Launch goal processing
                task = asyncio.create_task(process_goal(goal))
                active_goals[gid] = task

            # Cleanup finished tasks
            active_goals = {k: v for k, v in active_goals.items() if not v.done()}

        except Exception as e:
            print(f"[Orchestrator] Poll error: {e}")

        await asyncio.sleep(POLL_INTERVAL)


async def add_goal_cli(description: str, priority: int = 5):
    """Helper: add a goal from the command line."""
    await init_db()
    goal_id = await create_goal(description, priority)
    print(f"Goal created: id={goal_id}")
    return goal_id


async def stats_cli():
    """Helper: print current stats."""
    await init_db()
    s = await get_stats()
    print(f"Goals:  {s['goals']}")
    print(f"Tasks:  {s['tasks']}")
    print(f"Revenue: ${s['total_revenue_usd']:.2f}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) >= 3 and sys.argv[1] == "add":
        description = " ".join(sys.argv[2:])
        asyncio.run(add_goal_cli(description))
    elif len(sys.argv) >= 2 and sys.argv[1] == "stats":
        asyncio.run(stats_cli())
    else:
        asyncio.run(run())
