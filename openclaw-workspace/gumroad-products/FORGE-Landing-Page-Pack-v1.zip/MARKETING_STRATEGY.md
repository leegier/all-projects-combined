# FORGE — 22-Brand Marketing Playbook

**Strategy:** Same product. 22 brands. 22 different channels. Maximum surface area.

---

## The Play

One codebase → 22 identities → 22 audiences → 22 revenue streams converging on one product.

Each brand is positioned slightly differently but sells the same thing:
**AI-powered autonomous dev environment.**

When someone Googles "autonomous coding tool" — one of your 22 brands shows up.
When someone scrolls Reddit r/webdev — they find FOUNDRY.
When someone browses Product Hunt — they find FORGE.
When someone clicks a Twitter thread — they find AXIOM.

**You have 22 shots at the same customer.**

---

## The 22 Brands — Channel Assignments

| # | Brand | Channel | Audience | Primary Hook |
|---|-------|---------|----------|--------------|
| 1 | **FORGE** | Product Hunt | Senior devs / CTOs | Your AI engineers never sleep |
| 2 | **NEXUS** | Hacker News | Engineering managers | Run 5 agents in parallel |
| 3 | **FOUNDRY** | Reddit r/webdev | Agencies / freelancers | Take on 3x more clients |
| 4 | **PRAXIS** | IndieHackers | Solo devs / indie hackers | Output of 5-person team |
| 5 | **VORTEX** | Reddit r/programming | Automation lovers | Loop never exits until tests pass |
| 6 | **OVERMIND** | Reddit r/artificial | AI enthusiasts / ML | Agents debate before coding |
| 7 | **HELIX** | Reddit r/MachineLearning | ML practitioners | Never makes same mistake twice |
| 8 | **CORTEX** | LinkedIn | Dev teams at startups | AI-powered 10th engineer |
| 9 | **SYNAPSE** | Dev.to | Real-time collab devs | Like pair programming with 5 AIs |
| 10 | **CATALYST** | Reddit r/startups | Startup founders | Your technical co-founder |
| 11 | **ZENITH** | BetaList | Premium early adopters | Enterprise-grade without enterprise price |
| 12 | **STRATUM** | Lobsters (lobste.rs) | Backend / systems devs | Every layer of the stack automated |
| 13 | **PULSAR** | DevHunt.org | Reliability-focused devs | Ship code while you sleep |
| 14 | **QUORUM** | AlternativeTo | Quality-focused teams | Better than Copilot — it verifies too |
| 15 | **AXIOM** | Twitter/X | Thought leaders | 10-axiom thread goes viral |
| 16 | **REACTOR** | GitHub Trending | Open source community | Self-host. Own your AI dev environment. |
| 17 | **AETHER** | Uneed.best | Magic-seekers | Feels like magic, runs like infrastructure |
| 18 | **CONSTRUCT** | Reddit r/SideProject | Non-technical builders | Describe it. Watch it get built. |
| 19 | **CHIMERA** | Discord dev servers | Full-stack devs | 5 specialist minds in one |
| 20 | **MANIFEST** | YouTube | Visionary founders | I described an app. Watch what happened. |
| 21 | **DAEMON** | Hacker News (Show HN) | Unix/Linux hackers | Runs as a daemon. Keeps shipping. |
| 22 | **KERNEL** | GitHub Trending + HN | Systems programmers | Open source. Self-host. No vendor lock-in. |

---

## PHASE 1: Launch Infrastructure (Week 1-2)

### 1. Deploy All 22 Landing Pages
```bash
cd Z:/Dev/FORGE/brands
node generate-brands.js

# Deploy each to Netlify (free tier = 1 site per account OR paid for multiple)
# Cheapest: use Netlify/Vercel with custom domain per brand
# Each .html file is a complete standalone page
```

### 2. Buy All 22 Domains
Cost: ~$10-12/domain = ~$240 total for all 22
Priority order (buy first):
1. forge.dev (or forgedev.app)
2. nexusdev.app
3. manifests.dev (manifest.dev likely taken)
4. kerneldev.app
5. daemondev.app

### 3. Set Up Analytics
- One Plausible.io account = track all 22 domains
- UTM parameters on every link to see which brand converts
- The brand that gets most signups = your MAIN brand going forward

---

## PHASE 2: Content Blitz (Week 2-4)

### Reddit Strategy (7 brands = 7 subreddits)
**Rule:** One post per subreddit. NOT spammy. Genuine value posts.

Template for each:
```
Title: [Genuine question/insight about the problem]
Body:
- Describe the pain (1 paragraph)
- What I built to solve it (2 paragraphs)
- GIF/screenshot of self-healing in action
- Link in comments only (not body)
```

Subreddits to hit:
- r/webdev → FOUNDRY
- r/programming → VORTEX
- r/artificial → OVERMIND
- r/MachineLearning → HELIX
- r/startups → CATALYST
- r/SideProject → CONSTRUCT
- r/indiehackers → PRAXIS

**Spacing:** One post every 3 days. Don't hit them all at once.

### Hacker News (3 brands)
- NEXUS: "Show HN: Nexus — open-source multi-agent dev environment"
- DAEMON: "Show HN: Daemon — background AI process that writes code autonomously"
- KERNEL: "Show HN: Kernel — minimal self-hostable autonomous dev environment"

**Space these 2 weeks apart.** HN remembers. If one gets traction, hold the others.

### Product Hunt (1 brand = FORGE)
**Preparation:**
- Collect 50+ "upvote pledges" before launch
- Find a hunter with 1000+ followers
- Launch Tuesday or Wednesday at 12:01AM PST
- Have 5 people in the comments from minute 1
- Respond to EVERY comment within 15 minutes

### LinkedIn (1 brand = CORTEX)
Post series: "Building an AI engineering team from scratch"
- Post 1: "Why we built CORTEX" (founding story)
- Post 2: "The architecture: 5 agents, one loop" (technical)
- Post 3: "Month 1 results: what shocked us" (traction)

### Twitter/X (1 brand = AXIOM)
Thread: "10 axioms of autonomous software development"
1. Code should write itself when you know what you want
2. Tests shouldn't be written — they should be generated and passed autonomously
... (each axiom = a feature, framed as universal truth)

### YouTube (1 brand = MANIFEST)
Video 1: "I described an app at 9PM. It was live by midnight. Watch."
Video 2: "How the self-healing agent loop works (technical deep dive)"
Video 3: "Building a SaaS in 48 hours with autonomous agents"

---

## PHASE 3: SEO & Discovery (Month 2+)

### AlternativeTo Listings (QUORUM)
List as alternative to:
- GitHub Copilot
- Cursor
- Replit
- Codeium
- Amazon Q

Each comparison page = potential customer who searched for alternatives.

### GitHub Topics (REACTOR + KERNEL)
Add these topics to the public repo:
`ai-agent` `autonomous-coding` `developer-tools` `self-healing` `multi-agent` `code-generation` `devops-automation`

GitHub users browsing these topics find REACTOR/KERNEL.

### DevHunt + BetaList + Uneed (3 brands)
Submit ZENITH, PULSAR, AETHER to these discovery sites.
They drive consistent early adopter traffic.

---

## PHASE 4: Conversion Optimization

### The Hook Test
After 4 weeks, compare analytics:
- Which brand has lowest bounce rate?
- Which has highest "Start Session" clicks?
- Which has longest time-on-page?

→ The winning brand becomes your PRIMARY brand
→ Redirect all others to it OR keep them all running (more surface area)

### Upgrade Prompts (Critical)
The free tier is engineered to create pain at the right moment:
```
Agent paused mid-build 🧠
Your agent ran out of free runs before finishing.
[Continue with Pro →]   [Stay on free]
```

This triggers AFTER they've seen value — never before.

---

## REVENUE PROJECTIONS (Conservative)

| Month | Brands Active | Signups | Conversions (5%) | MRR |
|-------|--------------|---------|------------------|-----|
| 1 | 22 | 200 | 10 × $29 | $290 |
| 2 | 22 | 600 | 30 × $35 avg | $1,050 |
| 3 | 22 | 1,500 | 75 × $40 avg | $3,000 |
| 6 | 22 | 4,000 | 200 × $45 avg | $9,000 |
| 12 | 22 | 10,000 | 500 × $55 avg | $27,500 |

**12-month ARR target: $330,000**
**Path to $1M ARR: ~Month 18 at current trajectory**

---

## TOOLS YOU NEED

| Tool | Purpose | Cost |
|------|---------|------|
| Plausible.io | Analytics across all 22 domains | $9/mo |
| Netlify Pro | Host all 22 landing pages | $19/mo |
| Namecheap | Domain registrations | ~$240 one-time |
| Stripe | Payments for all brands | 2.9% + $0.30/txn |
| Resend | Email for all brands | Free tier |
| Posthog | Product analytics | Free tier |

**Total monthly overhead: ~$30/mo**

---

## MAX'S ROLE IN THIS

MAX should:
1. Post to Reddit on the schedule above (use the `social-poster` skill)
2. Monitor AlternativeTo for competitor mentions
3. Track signups across all 22 domains
4. Respond to Reddit comments on all posts
5. Post the Twitter/X thread for AXIOM
6. Submit to BetaList, Uneed, DevHunt for the discovery brands

Commands:
```bash
# MAX posts the FOUNDRY Reddit post
openclaw agent --agent main --message "Post to r/webdev about FOUNDRY - the autonomous dev environment for agencies. Use the hook from MARKETING_STRATEGY.md"

# MAX tracks signups
openclaw agent --agent main --message "Check analytics for all FORGE brand domains. Report which brand has best engagement."
```
