FORGE Landing Page Template Pack — 22 Multi-Brand SaaS Pages
=============================================================

Thank you for purchasing the FORGE Landing Page Template Pack.
This pack contains 22 production-ready, fully customizable HTML landing pages
built for SaaS, dev tools, and tech products — each with its own distinct brand
identity, color palette, and copy direction.

----------------------------------------------------------------------
WHAT'S INCLUDED
----------------------------------------------------------------------

landing-pages/          22 standalone HTML landing pages (one per brand):
  aether.html           Ethereal cloud/AI platform
  axiom.html            Logic-first developer tooling
  catalyst.html         Accelerator / growth platform
  chimera.html          Hybrid / multi-paradigm tooling
  construct.html        Infrastructure / builder platform
  cortex.html           AI cognition / intelligence platform
  daemon.html           Background services / automation
  forge.html            Core build & deployment platform
  foundry.html          Creation / manufacturing metaphor
  helix.html            Data / biology / spiral systems
  kernel.html           Low-level / systems programming
  manifest.html         Deployment manifests / orchestration
  nexus.html            Connection / integration hub
  overmind.html         AI orchestration / control layer
  praxis.html           Execution / workflow platform
  pulsar.html           Real-time / event-driven systems
  quorum.html           Consensus / collaboration tooling
  reactor.html          Reactive / event-stream platform
  stratum.html          Layered infrastructure / observability
  synapse.html          Neural / connectivity platform
  vortex.html           High-throughput / data pipeline
  zenith.html           Peak performance / optimization

brands.config.json      Master configuration — brand tokens, colors,
                        taglines, and metadata for all 22 brands.

generate-brands.js      Node.js generator script — regenerate or
                        customize any/all pages from config.

MARKETING_STRATEGY.md   Complete go-to-market strategy document covering
                        positioning, channels, and growth tactics.

MARKETING_PLAYBOOK.json Structured playbook with campaigns, messaging
                        frameworks, and launch sequences.

README.txt              This file.

----------------------------------------------------------------------
HOW TO CUSTOMIZE
----------------------------------------------------------------------

Each HTML file is fully self-contained — no build step required. You can:

  1. EDIT DIRECTLY — Open any .html file in a text editor or browser
     and modify copy, colors, links, and CTAs inline.

  2. USE THE GENERATOR — Modify brands.config.json to change brand
     tokens (name, tagline, colors, features) and then run the
     generator to rebuild all pages consistently:

        node generate-brands.js

  3. ADD A NEW BRAND — Duplicate an existing entry in brands.config.json,
     update the brand fields, and run the generator. A new .html file
     will be created automatically.

----------------------------------------------------------------------
NODE.JS USAGE (generate-brands.js)
----------------------------------------------------------------------

Requirements:
  - Node.js v16 or higher (https://nodejs.org)
  - No npm packages required — uses Node built-ins only

Steps:

  1. Install Node.js if you haven't already.

  2. Open a terminal in the directory containing generate-brands.js.

  3. Run:
        node generate-brands.js

     This will read brands.config.json and write updated HTML files
     into the landing-pages/ directory.

  4. To target a single brand, you can pass a brand name as an argument
     (check the script header for supported flags):
        node generate-brands.js --brand=nexus

Configuration reference (brands.config.json):
  - "name"        — Brand display name
  - "slug"        — URL-safe identifier (matches filename)
  - "tagline"     — Hero headline / value proposition
  - "description" — Supporting subheading copy
  - "colors"      — Primary, accent, and background hex values
  - "features"    — Array of feature cards (icon, title, body)
  - "cta"         — Call-to-action button label and URL

----------------------------------------------------------------------
LICENSE
----------------------------------------------------------------------

This template pack is licensed for use on unlimited personal and
commercial projects. You may NOT resell, redistribute, or repackage
these templates as a standalone template product.

----------------------------------------------------------------------
SUPPORT
----------------------------------------------------------------------

Questions? Reach out via your Gumroad purchase receipt.

Built with FORGE — https://forge.dev
