#!/usr/bin/env node
/**
 * FORGE Multi-Brand Landing Page Generator
 * Generates 22 branded landing pages from a single config
 * Run: node generate-brands.js
 */

const fs = require('fs');
const path = require('path');

const config = JSON.parse(fs.readFileSync('./brands.config.json', 'utf-8'));

function generateLandingPage(brand) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${brand.name} — ${brand.tagline}</title>
  <meta name="description" content="${brand.subTagline}">
  <meta property="og:title" content="${brand.name} — ${brand.tagline}">
  <meta property="og:description" content="${brand.subTagline}">
  <meta property="og:type" content="website">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${brand.name} — ${brand.tagline}">
  <meta name="twitter:description" content="${brand.subTagline}">
  <style>
    :root {
      --primary: ${brand.primaryColor};
      --secondary: ${brand.secondaryColor};
      --accent: ${brand.accentColor};
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      background: var(--secondary);
      color: #f5f5f5;
      line-height: 1.6;
    }
    nav {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem 4rem;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    .logo {
      font-size: 1.5rem;
      font-weight: 900;
      letter-spacing: 0.15em;
      color: var(--primary);
      text-decoration: none;
    }
    .nav-links { display: flex; gap: 2rem; align-items: center; }
    .nav-links a { color: #aaa; text-decoration: none; font-size: 0.9rem; }
    .nav-links a:hover { color: #fff; }
    .btn-nav {
      background: var(--primary);
      color: #fff;
      padding: 0.6rem 1.4rem;
      border-radius: 6px;
      font-weight: 600;
      text-decoration: none;
      font-size: 0.9rem;
    }
    .hero {
      text-align: center;
      padding: 7rem 4rem 5rem;
      max-width: 900px;
      margin: 0 auto;
    }
    .hero-badge {
      display: inline-block;
      background: rgba(255,255,255,0.08);
      border: 1px solid rgba(255,255,255,0.15);
      padding: 0.4rem 1rem;
      border-radius: 100px;
      font-size: 0.8rem;
      color: var(--accent);
      margin-bottom: 2rem;
      letter-spacing: 0.1em;
    }
    h1 {
      font-size: clamp(2.5rem, 6vw, 4.5rem);
      font-weight: 900;
      line-height: 1.1;
      margin-bottom: 1.5rem;
      background: linear-gradient(135deg, #fff 0%, var(--accent) 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .hero-sub {
      font-size: 1.25rem;
      color: #888;
      max-width: 600px;
      margin: 0 auto 2.5rem;
    }
    .btn-primary {
      display: inline-block;
      background: var(--primary);
      color: #fff;
      padding: 1rem 2.5rem;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: 700;
      text-decoration: none;
      margin-right: 1rem;
      transition: opacity 0.2s;
    }
    .btn-primary:hover { opacity: 0.85; }
    .btn-ghost {
      display: inline-block;
      color: #aaa;
      padding: 1rem 2rem;
      font-size: 1rem;
      text-decoration: none;
    }
    .demo-window {
      margin: 4rem auto;
      max-width: 900px;
      background: #0D0D0D;
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 12px;
      overflow: hidden;
    }
    .demo-bar {
      background: #1A1A1A;
      padding: 0.75rem 1rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      border-bottom: 1px solid rgba(255,255,255,0.08);
    }
    .demo-dot { width: 12px; height: 12px; border-radius: 50%; }
    .demo-dot.red { background: #FF5F57; }
    .demo-dot.yellow { background: #FEBC2E; }
    .demo-dot.green { background: #28C840; }
    .demo-code {
      padding: 2rem;
      font-family: 'Fira Code', 'Consolas', monospace;
      font-size: 0.85rem;
      line-height: 1.8;
      color: #ccc;
    }
    .code-comment { color: #555; }
    .code-key { color: var(--accent); }
    .code-string { color: #a8e6cf; }
    .code-fn { color: #f8c291; }
    .features {
      padding: 5rem 4rem;
      max-width: 1100px;
      margin: 0 auto;
    }
    .section-label {
      text-align: center;
      color: var(--primary);
      font-size: 0.8rem;
      font-weight: 700;
      letter-spacing: 0.2em;
      margin-bottom: 1rem;
      text-transform: uppercase;
    }
    .section-title {
      text-align: center;
      font-size: 2.5rem;
      font-weight: 800;
      margin-bottom: 3rem;
    }
    .feature-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 1.5rem;
    }
    .feature-card {
      background: rgba(255,255,255,0.03);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 12px;
      padding: 1.5rem;
    }
    .feature-icon { font-size: 1.8rem; margin-bottom: 1rem; }
    .feature-card h3 { font-size: 1rem; font-weight: 700; margin-bottom: 0.5rem; color: #fff; }
    .feature-card p { font-size: 0.9rem; color: #777; }
    .social-proof {
      text-align: center;
      padding: 4rem;
      background: rgba(255,255,255,0.02);
      border-top: 1px solid rgba(255,255,255,0.05);
      border-bottom: 1px solid rgba(255,255,255,0.05);
    }
    .quote {
      font-size: 1.5rem;
      font-style: italic;
      color: #ccc;
      max-width: 700px;
      margin: 0 auto;
    }
    .pricing {
      padding: 5rem 4rem;
      max-width: 1100px;
      margin: 0 auto;
    }
    .pricing-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 1.5rem;
      margin-top: 3rem;
    }
    .plan {
      background: rgba(255,255,255,0.03);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 12px;
      padding: 2rem;
    }
    .plan.featured {
      border-color: var(--primary);
      background: rgba(255,255,255,0.06);
    }
    .plan-name { font-size: 0.8rem; font-weight: 700; letter-spacing: 0.15em; color: var(--accent); text-transform: uppercase; }
    .plan-price { font-size: 2.5rem; font-weight: 900; margin: 0.5rem 0; }
    .plan-price span { font-size: 1rem; color: #555; font-weight: 400; }
    .plan-desc { font-size: 0.85rem; color: #666; margin-bottom: 1.5rem; }
    .plan ul { list-style: none; }
    .plan ul li { font-size: 0.9rem; color: #aaa; padding: 0.4rem 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
    .plan ul li::before { content: '✓  '; color: var(--primary); }
    .cta-section {
      text-align: center;
      padding: 6rem 4rem;
      background: linear-gradient(135deg, rgba(${hexToRgb(brand.primaryColor)}, 0.15) 0%, transparent 60%);
    }
    .cta-section h2 { font-size: 2.5rem; font-weight: 900; margin-bottom: 1rem; }
    .cta-section p { color: #888; font-size: 1.1rem; margin-bottom: 2rem; }
    footer {
      text-align: center;
      padding: 2rem;
      color: #444;
      font-size: 0.8rem;
      border-top: 1px solid rgba(255,255,255,0.05);
    }
    @media (max-width: 768px) {
      nav { padding: 1rem 1.5rem; }
      .hero { padding: 4rem 1.5rem 3rem; }
      .features, .pricing { padding: 3rem 1.5rem; }
    }
  </style>
</head>
<body>
  <nav>
    <a href="/" class="logo">${brand.name}</a>
    <div class="nav-links">
      <a href="#features">Features</a>
      <a href="#pricing">Pricing</a>
      <a href="#" class="btn-nav">Get Early Access</a>
    </div>
  </nav>

  <section class="hero">
    <div class="hero-badge">NOW IN EARLY ACCESS</div>
    <h1>${brand.tagline}</h1>
    <p class="hero-sub">${brand.subTagline}</p>
    <a href="#pricing" class="btn-primary">${brand.ctaText}</a>
    <a href="#features" class="btn-ghost">See how it works ↓</a>
  </section>

  <div class="demo-window">
    <div class="demo-bar">
      <div class="demo-dot red"></div>
      <div class="demo-dot yellow"></div>
      <div class="demo-dot green"></div>
      <span style="color:#555;font-size:0.8rem;margin-left:0.5rem">${brand.name.toLowerCase()} — agent console</span>
    </div>
    <div class="demo-code">
      <span class="code-comment">// You said:</span><br>
      <span class="code-key">&gt;</span> <span class="code-string">"Build a REST API with JWT auth and user management"</span><br><br>
      <span class="code-comment">// ${brand.heroKeyword} Agent started...</span><br>
      <span class="code-fn">✓ Planner</span> → Generated 6-step execution plan<br>
      <span class="code-fn">✓ Executor</span> → Scaffolded project structure (14 files)<br>
      <span class="code-fn">✓ Executor</span> → Wrote auth middleware, routes, models<br>
      <span class="code-fn">⚡ Tester</span> → Running 24 tests...<br>
      <span class="code-comment">  ✗ 2 failed: missing bcrypt import, async error</span><br>
      <span class="code-fn">🔧 Fixer</span> → Analyzing failures... applying patches<br>
      <span class="code-fn">✓ Tester</span> → 24/24 passed ✅<br>
      <span class="code-fn">✓ Reviewer</span> → Code approved. Committing...<br><br>
      <span class="code-key" style="color:${brand.accentColor}">✓ Done in 47 seconds. 14 files written. 24 tests passing.</span>
    </div>
  </div>

  <section class="features" id="features">
    <div class="section-label">What it does</div>
    <h2 class="section-title">Everything your team does.<br>Done autonomously.</h2>
    <div class="feature-grid">
      <div class="feature-card">
        <div class="feature-icon">🤖</div>
        <h3>Autonomous Code Generation</h3>
        <p>Tell it what to build. A planner, executor, and reviewer agent collaborate to ship complete features.</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">🔧</div>
        <h3>Self-Healing Agents</h3>
        <p>Tests fail? The fixer agent analyzes the error and retries automatically. Up to 3 healing cycles per step.</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">💻</div>
        <h3>Real Terminal, Real Execution</h3>
        <p>Not a sandbox. A real PTY terminal streaming live output. Your code actually runs as it gets written.</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">🌿</div>
        <h3>Git-Native Workflows</h3>
        <p>Every session gets an isolated Git worktree. Every change is tracked, diffed, and committable.</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">👥</div>
        <h3>Multiplayer Sessions</h3>
        <p>Invite teammates to watch or collaborate on a live session. Shared terminal, shared context.</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">🔒</div>
        <h3>Docker-Sandboxed</h3>
        <p>Every session runs in isolation. No cross-contamination. Safe to run untested agent code.</p>
      </div>
    </div>
  </section>

  <div class="social-proof">
    <p class="quote">${brand.socialProof}</p>
  </div>

  <section class="pricing" id="pricing">
    <div class="section-label">Pricing</div>
    <h2 class="section-title">Start free. Scale when you're ready.</h2>
    <div class="pricing-grid">
      <div class="plan">
        <div class="plan-name">Free</div>
        <div class="plan-price">$0<span>/mo</span></div>
        <div class="plan-desc">Get hooked first.</div>
        <ul>
          <li>3 active sessions</li>
          <li>25 agent runs/day</li>
          <li>Shared compute</li>
          <li>Git diff view</li>
          <li>Community support</li>
        </ul>
      </div>
      <div class="plan featured">
        <div class="plan-name">Pro</div>
        <div class="plan-price">$29<span>/mo</span></div>
        <div class="plan-desc">For serious builders.</div>
        <ul>
          <li>5 active sessions</li>
          <li>Unlimited agent runs</li>
          <li>Dedicated containers</li>
          <li>Self-healing (3 cycles)</li>
          <li>Git automation</li>
          <li>Priority support</li>
        </ul>
      </div>
      <div class="plan">
        <div class="plan-name">Power</div>
        <div class="plan-price">$79<span>/mo</span></div>
        <div class="plan-desc">Maximum output.</div>
        <ul>
          <li>15 active sessions</li>
          <li>Parallel agents</li>
          <li>Faster machines</li>
          <li>Advanced self-healing</li>
          <li>Multi-agent parallelism</li>
          <li>Git automation + CI</li>
        </ul>
      </div>
      <div class="plan">
        <div class="plan-name">Team</div>
        <div class="plan-price">$49<span>/user/mo</span></div>
        <div class="plan-desc">Build together.</div>
        <ul>
          <li>Unlimited sessions</li>
          <li>Shared workspaces</li>
          <li>Role permissions</li>
          <li>Org billing</li>
          <li>Dedicated infra</li>
          <li>SLA + priority support</li>
        </ul>
      </div>
    </div>
  </section>

  <section class="cta-section">
    <h2>Stop writing code alone.</h2>
    <p>Your AI development team is ready. No setup. No config. Just describe what you want to build.</p>
    <a href="#" class="btn-primary" style="font-size:1.2rem;padding:1.2rem 3rem">${brand.ctaText}</a>
  </section>

  <footer>
    <p>&copy; 2026 ${brand.name}. All rights reserved. &nbsp;·&nbsp; <a href="#" style="color:#555">Privacy</a> &nbsp;·&nbsp; <a href="#" style="color:#555">Terms</a></p>
  </footer>
</body>
</html>`;
}

function hexToRgb(hex) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}`
    : '255, 255, 255';
}

// Generate landing pages
const outputDir = './landing-pages';
if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

config.brands.forEach(brand => {
  const html = generateLandingPage(brand);
  const filePath = path.join(outputDir, `${brand.slug}.html`);
  fs.writeFileSync(filePath, html);
  console.log(`✓ Generated: ${brand.name} → ${filePath}`);
});

// Generate marketing playbook
const playbook = config.brands.map(brand => ({
  brand: brand.name,
  domain: brand.domain,
  channel: brand.channel,
  audience: brand.audience,
  hook: brand.uniqueHook,
  strategy: brand.channelStrategy
}));

fs.writeFileSync('./MARKETING_PLAYBOOK.json', JSON.stringify(playbook, null, 2));
console.log('\n✓ Marketing playbook generated: MARKETING_PLAYBOOK.json');

// Generate deploy script
const deployScript = `#!/bin/bash
# Deploy all 22 brand landing pages
# Each brand gets its own Netlify/Vercel deployment

${config.brands.map(b => `
echo "Deploying ${b.name}..."
# netlify deploy --prod --dir=brands/landing-pages --site=${b.slug}-app
# OR: vercel --prod brands/landing-pages/${b.slug}.html
`).join('')}

echo "All 22 brands deployed."
`;

fs.writeFileSync('./deploy-all-brands.sh', deployScript);
console.log('✓ Deploy script generated: deploy-all-brands.sh');

console.log(`\n🔥 ${config.brands.length} brand landing pages generated!`);
console.log('Run: node generate-brands.js');
